
import { Router } from 'express';
import { z } from 'zod';

import { authed, normalisePhone, requireRole } from '../auth.js';
import { config } from '../config.js';
import SmsSettingsModel from '../models/SmsSettings.js';
import { HttpError, parse } from '../http.js';
import {
  SmsError,
  forgetSmsSettings,
  renderOtp,
  sendSms,
  smsSettings,
} from '../sms.js';

export const smsAdmin = Router();

const PEARL_SMS_URL = 'https://sms.pearlsms.com/public/sms/send';

smsAdmin.use(authed, requireRole('admin'));

const masked = (key: string | null) =>
  key ? `••••${key.slice(-4)}` : null;

const staticOtpAllowed =
  !config.isProd && config.testOtpEnabled;

const view = async () => {
  const settings = await smsSettings();

  const effectiveOtpChannel = staticOtpAllowed
    ? settings.otpChannel
    : 'sms';

  return {
    apiUrl: PEARL_SMS_URL,
    senderId: settings.senderId,
    smsType: settings.smsType,
    otpTemplate: settings.otpTemplate,
    otpChannel: effectiveOtpChannel,
    staticOtpAllowed,
    apiKeySet: Boolean(settings.apiKey),
    apiKeyHint: masked(settings.apiKey),
    updatedAt: settings.updatedAt,
    inUse:
      config.authMode === 'sms' &&
      effectiveOtpChannel === 'sms',
  };
};

const trimmed = (max: number) =>
  z.string().trim().max(max);

const schema = z.object({
  senderId: trimmed(11)
    .regex(
      /^[A-Za-z0-9]{3,11}$/,
      'Sender ID is 3 to 11 letters or digits, like SPPLFW',
    )
    .transform((value) => value.toUpperCase()),

  smsType: trimmed(20)
    .regex(
      /^[A-Za-z_]{2,20}$/,
      'SMS type is a word like TRANS',
    )
    .transform((value) => value.toUpperCase()),

  apiKey: trimmed(200).optional(),

  otpTemplate: trimmed(480)
    .min(8)
    .refine(
      (value) => value.includes('{otp}'),
      'The message must contain {otp} where the code goes',
    ),

  // Retained for compatibility with the existing admin app.
  // The submitted URL is deliberately ignored.
  apiUrl: trimmed(300).optional(),

  otpChannel: z.enum(['static', 'sms']).optional(),
});

smsAdmin.get('/sms', async (_req, res) => {
  res.json(await view());
});

smsAdmin.put('/sms', async (req, res) => {
  const body = parse(schema, req.body);

  if (
    body.otpChannel === 'static' &&
    !staticOtpAllowed
  ) {
    throw new HttpError(
      400,
      'test_otp_disabled',
      'Static test OTPs are disabled. Enable TEST_OTP_ENABLED in a non-production environment or configure Pearl SMS.',
    );
  }

  const update: Record<string, unknown> = {
    apiUrl: PEARL_SMS_URL,
    senderId: body.senderId,
    smsType: body.smsType,
    otpTemplate: body.otpTemplate,
    updatedBy: req.user!.id,
  };

  if (body.apiKey) {
    update.apiKey = body.apiKey;
  }

  if (body.otpChannel !== undefined) {
    update.otpChannel = body.otpChannel;
  } else if (!staticOtpAllowed) {
    update.otpChannel = 'sms';
  }

  await SmsSettingsModel.findOneAndUpdate(
    { key: 'default' },
    {
      $set: update,
      $setOnInsert: { key: 'default' },
    },
    {
      upsert: true,
      returnDocument: 'after',
      runValidators: true,
      setDefaultsOnInsert: true,
    },
  );

  forgetSmsSettings();

  res.json(await view());
});

/** Sends a sample OTP to test the configured Pearl SMS gateway. */
smsAdmin.post('/sms/test', async (req, res) => {
  const body = parse(
    z.object({
      phone: z.string().min(10).max(15),
    }),
    req.body,
  );

  const phone = normalisePhone(body.phone);

  forgetSmsSettings();

  const settings = await smsSettings();

  try {
    const result = await sendSms(
      phone,
      renderOtp(settings.otpTemplate, '123456'),
      settings,
    );

    res.json({
      sent: true,
      requestId: result.requestId,
    });
  } catch (error) {
    if (error instanceof SmsError) {
      throw new HttpError(
        error.reason === 'not_configured' ? 422 : 502,
        `sms_${error.reason}`,
        error.reason === 'not_configured'
          ? 'Enter the Pearl SMS sender ID and API key first.'
          : `Pearl SMS gateway error: ${error.message}`,
      );
    }

    throw error;
  }
});
